﻿using System;

namespace _39013219___JWTAuthentication_PROJECT_2.Authentication
{
    public class Response
    {
        public string? Status { get; set; }
        public string? Message { get; set; }
    }
}


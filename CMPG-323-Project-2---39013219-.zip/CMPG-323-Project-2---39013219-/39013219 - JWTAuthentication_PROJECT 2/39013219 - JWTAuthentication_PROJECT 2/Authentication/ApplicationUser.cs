﻿using System;
using Microsoft.AspNetCore.Identity;

namespace _39013219___JWTAuthentication_PROJECT_2.Authentication
{
    public class ApplicationUser : IdentityUser
    {
        // Additional properties
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
    }
}


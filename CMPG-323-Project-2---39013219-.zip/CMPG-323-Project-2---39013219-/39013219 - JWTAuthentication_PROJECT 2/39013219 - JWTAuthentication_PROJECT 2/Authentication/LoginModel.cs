﻿using System;
using System.ComponentModel.DataAnnotations;

namespace _39013219___JWTAuthentication_PROJECT_2n.Authentication
{
    public class LoginModel
    {
        [Required(ErrorMessage = "User Name is required")]
        public string? Username { get; set; }

        [Required(ErrorMessage = "Password is required")]
        public string? Password { get; set; }
    }
}

﻿using _39013219___JWTAuthentication_PROJECT_2.Authentication;
using _39013219___JWTAuthentication_PROJECT_2n.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace _39013219___JWTAuthentication_PROJECT_2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly IConfiguration _configuration;

        public AuthenticateController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, IConfiguration configuration)
        {
            this.userManager = userManager;
            this.roleManager = roleManager;
            _configuration = configuration;
        }
        public class TokenModel
        {
            public string Token { get; set; }
            public string RefreshToken { get; set; }
        }

        // Login Endpoint
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            var user = await userManager.FindByNameAsync(model.Username);
            if (user != null && await userManager.CheckPasswordAsync(user, model.Password))
            {
                var userRoles = await userManager.GetRolesAsync(user);

                var authClaims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.UserName),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                };

                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));

                var token = new JwtSecurityToken(
                    issuer: _configuration["JWT:ValidIssuer"],
                    audience: _configuration["JWT:ValidAudience"],
                    expires: DateTime.Now.AddHours(3),
                    claims: authClaims,
                    signingCredentials: new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256)
                );

                var refreshToken = Guid.NewGuid().ToString(); // Generate a new refresh token
                                                              // Store the refresh token (ideally in the database associated with the user)


                return Ok(new TokenModel
                {
                    Token = new JwtSecurityTokenHandler().WriteToken(token),
                    RefreshToken = refreshToken
                });
            }
            return Unauthorized();
        }
        // In your ApplicationUser class, add properties to store the refresh token and its expiration date.
        public class ApplicationUser : IdentityUser
        {
            public string RefreshToken { get; set; }
            public DateTime RefreshTokenExpiryTime { get; set; }
        }

        // Implement the ValidateRefreshToken method.
        private bool ValidateRefreshToken(ApplicationUser user, string refreshToken)
        {
            // Check if the provided refresh token matches the one stored for the user.
            if (user.RefreshToken != refreshToken)
            {
                return false;
            }

            // Check if the refresh token has expired.
            if (user.RefreshTokenExpiryTime <= DateTime.Now)
            {
                return false;
            }

            return true; // The refresh token is valid.
        }

        // When generating a new refresh token, store it and its expiration time in the user object.
        private void UpdateRefreshToken(ApplicationUser user, string newRefreshToken)
        {
            user.RefreshToken = newRefreshToken;
            user.RefreshTokenExpiryTime = DateTime.Now.AddDays(7); // Set the expiry time (e.g., 7 days). 
        }


        [HttpPost]
        [Route("logout")]
        public async Task<IActionResult> Logout([FromBody] TokenModel tokenModel)
        {
            // Invalidate the refresh token (e.g., remove it from the database)

            return Ok(new Response { Status = "Success", Message = "User logged out successfully!" });
        }
        // Register User Endpoint
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register([FromBody] RegisterModel model)
        {
            // Validate email format
            if (!Regex.IsMatch(model.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                return StatusCode(StatusCodes.Status400BadRequest, new Response { Status = "Error", Message = "Invalid email format!" });
            }

            // Validate password complexity
            if (model.Password.Length < 8 ||
                !Regex.IsMatch(model.Password, @"[A-Z]") ||
                !Regex.IsMatch(model.Password, @"[a-z]") ||
                !Regex.IsMatch(model.Password, @"[0-9]"))
            {
                return StatusCode(StatusCodes.Status400BadRequest, new Response { Status = "Error", Message = "Password does not meet complexity requirements!" });
            }
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var userExists = await userManager.FindByNameAsync(model.Username);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });

            ApplicationUser user = new ApplicationUser()
            {
                Email = model.Email,
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = model.Username
            };

            var result = await userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User creation failed! Please check user details and try again." });
            
            // Assign default role to user
            if (!await roleManager.RoleExistsAsync(UserRoles.User))
                await roleManager.CreateAsync(new IdentityRole(UserRoles.User));

            await userManager.AddToRoleAsync(user, UserRoles.User);


            return Ok(new Response { Status = "Success", Message = "User created successfully!" });
        }

        // Register Admin Endpoint
        [HttpPost]
        [Route("register-admin")]
        public async Task<IActionResult> RegisterAdmin([FromBody] RegisterModel model)
        {
            // Validate email format
            if (!Regex.IsMatch(model.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                return StatusCode(StatusCodes.Status400BadRequest, new Response { Status = "Error", Message = "Invalid email format!" });
            }

            // Validate password complexity
            if (model.Password.Length < 8 ||
                !Regex.IsMatch(model.Password, @"[A-Z]") ||
                !Regex.IsMatch(model.Password, @"[a-z]") ||
                !Regex.IsMatch(model.Password, @"[0-9]"))
            {
                return StatusCode(StatusCodes.Status400BadRequest, new Response { Status = "Error", Message = "Password does not meet complexity requirements!" });
            }
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var userExists = await userManager.FindByNameAsync(model.Username);
            if (userExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });

            ApplicationUser user = new ApplicationUser()
            {
                Email = model.Email,
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = model.Username
            };
            var result = await userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User creation failed! Please check user details and try again." });

            if (!await roleManager.RoleExistsAsync(UserRoles.Admin))
                await roleManager.CreateAsync(new IdentityRole(UserRoles.Admin));
            if (!await roleManager.RoleExistsAsync(UserRoles.User))
                await roleManager.CreateAsync(new IdentityRole(UserRoles.User));

            if (await roleManager.RoleExistsAsync(UserRoles.Admin))
            {
                await userManager.AddToRoleAsync(user, UserRoles.Admin);
            }

            return Ok(new Response { Status = "Success", Message = "Admin user created successfully!" });
        }
        [Authorize(Roles = UserRoles.Admin)]
        [HttpGet]
        [Route("admin-only-endpoint")]
        public IActionResult AdminOnlyEndpoint()
        {
            return Ok("This is an admin-only endpoint.");
        }
    }
}
